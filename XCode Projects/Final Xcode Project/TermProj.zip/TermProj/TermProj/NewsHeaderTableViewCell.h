

#import <UIKit/UIKit.h>

@interface NewsHeaderTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *newsImage;

@end

