

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController
- (IBAction)metro:(id)sender;
- (IBAction)toast:(id)sender;

@end

