

#import "News.h"

@implementation News

@end

