

#import "Event.h"

@implementation Event

@end
