

#import <UIKit/UIKit.h>

@interface DetailNewsTableViewController : UITableViewController

@property (strong, nonatomic) UIImage *newsImage;
@property (strong, nonatomic) NSString *newsTitle;
@property (strong, nonatomic) NSString *newsDate;
@property (strong, nonatomic) NSString *newsText;

@end

