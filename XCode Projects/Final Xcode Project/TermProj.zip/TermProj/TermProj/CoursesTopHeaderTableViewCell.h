

#import <UIKit/UIKit.h>

@interface CoursesTopHeaderTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *programNameLabel;
@property (strong, nonatomic) IBOutlet UIImageView *imageView;

@end

