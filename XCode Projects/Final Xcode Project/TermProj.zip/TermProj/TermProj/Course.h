

#import <Foundation/Foundation.h>

@interface Course : NSObject

@property(strong, nonatomic) NSString *cid;
@property(strong, nonatomic) NSString *cname;
@property(strong, nonatomic) NSString *credit;
@property(strong, nonatomic) NSString *lect;
@property(strong, nonatomic) NSString *lab;

@end

