
#import "Course.h"

@implementation Course

@end

