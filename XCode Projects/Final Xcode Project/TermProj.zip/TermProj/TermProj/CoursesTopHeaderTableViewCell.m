//
//  CoursesTopHeaderTableViewCell.m
//  TableView 3
//
//  Created by Branko Cirovic on 2018-01-11.
//  Copyright © 2018 Branko Cirovic. All rights reserved.
//

#import "CoursesTopHeaderTableViewCell.h"

@implementation CoursesTopHeaderTableViewCell

@synthesize imageView;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end


