

#import <Foundation/Foundation.h>

@interface Semester : NSObject

@property(strong, nonatomic) NSString *number;
@property(strong, nonatomic) NSMutableArray *courses;

@end

